LensSynth: Synthesizer for Lenses
====================

Requirements
------------
Ocaml > 4.01.0

Quick and Dirty Installation Instructions
-----------------------------------------
opam install core  
opam install menhir  
opam install ounit  
opam install ppx_deriving
pip install EasyProcess  
make

Example Execution
-----------------
./cmdline.native /path/to/test/directory

Test Locations
--------------
tests/
